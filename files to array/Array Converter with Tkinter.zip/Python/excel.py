import tkinter as tk
from tkinter import filedialog, ttk
import numpy as np
import pandas as pd
import json
from docx import Document
import PyPDF2
import os
from ttkthemes import ThemedTk

class FileArrayConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("File Array Converter")
        self.root.geometry("800x600")
        
        # Configure style
        style = ttk.Style()
        style.configure("Custom.TFrame", background="#f5f5f5")
        style.configure("Custom.TButton",
                       padding=10,
                       font=('Helvetica', 10, 'bold'))
        style.configure("Custom.TLabel",
                       font=('Helvetica', 10),
                       padding=5)
        style.configure("Custom.TRadiobutton",
                       font=('Helvetica', 10),
                       padding=5)
        style.configure("Title.TLabel",
                       font=('Helvetica', 14, 'bold'),
                       padding=10)
        
        # Main container
        self.create_main_container()
        
        # Configure grid weights for responsiveness
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
    def create_main_container(self):
        main_frame = ttk.Frame(self.root, style="Custom.TFrame", padding="20")
        main_frame.grid(row=0, column=0, sticky="nsew")
        main_frame.grid_columnconfigure(0, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, 
                              text="Multi-format File Array Converter",
                              style="Title.TLabel")
        title_label.grid(row=0, column=0, pady=10)
        
        # File selection section
        file_frame = self.create_file_section(main_frame)
        file_frame.grid(row=1, column=0, sticky="ew", pady=10)
        
        # Direction toggle section
        direction_frame = self.create_direction_section(main_frame)
        direction_frame.grid(row=2, column=0, sticky="ew", pady=10)
        
        # Result section
        result_frame = self.create_result_section(main_frame)
        result_frame.grid(row=3, column=0, sticky="nsew", pady=10)
        
        # Configure weights for main_frame
        main_frame.grid_rowconfigure(3, weight=1)
        
    def create_file_section(self, parent):
        file_frame = ttk.Frame(parent)
        file_frame.grid_columnconfigure(1, weight=1)
        
        select_btn = ttk.Button(file_frame, 
                              text="Select File",
                              command=self.load_file,
                              style="Custom.TButton")
        select_btn.grid(row=0, column=0, padx=5)
        
        formats_label = ttk.Label(file_frame,
                                text="Supported: Excel, CSV, Text, JSON, PDF, DOCX",
                                style="Custom.TLabel")
        formats_label.grid(row=0, column=1, padx=5)
        
        return file_frame
        
    def create_direction_section(self, parent):
        direction_frame = ttk.LabelFrame(parent,
                                       text="Reading Direction",
                                       padding="10")
        direction_frame.grid_columnconfigure((0, 1), weight=1)
        
        self.direction = tk.StringVar(value="top-bottom")
        
        top_bottom = ttk.Radiobutton(direction_frame,
                                    text="Top to Bottom",
                                    variable=self.direction,
                                    value="top-bottom",
                                    style="Custom.TRadiobutton")
        left_right = ttk.Radiobutton(direction_frame,
                                    text="Left to Right",
                                    variable=self.direction,
                                    value="left-right",
                                    style="Custom.TRadiobutton")
        
        top_bottom.grid(row=0, column=0)
        left_right.grid(row=0, column=1)
        
        return direction_frame
        
    def create_result_section(self, parent):
        result_frame = ttk.LabelFrame(parent,
                                    text="Array Output",
                                    padding="10")
        result_frame.grid_columnconfigure(0, weight=1)
        result_frame.grid_rowconfigure(0, weight=1)
        
        # Text widget with custom font and colors
        self.result_display = tk.Text(result_frame,
                                    wrap=tk.WORD,
                                    font=('Consolas', 11),
                                    bg='#ffffff',
                                    fg='#333333',
                                    padx=10,
                                    pady=10)
        self.result_display.grid(row=0, column=0, sticky="nsew")
        
        # Scrollbar with custom styling
        scrollbar = ttk.Scrollbar(result_frame,
                                orient="vertical",
                                command=self.result_display.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.result_display.configure(yscrollcommand=scrollbar.set)
        
        # Copy button
        copy_btn = ttk.Button(result_frame,
                            text="Copy to Clipboard",
                            command=self.copy_to_clipboard,
                            style="Custom.TButton")
        copy_btn.grid(row=1, column=0, columnspan=2, pady=(10, 0))
        
        return result_frame

    def read_file_content(self, filename):
        ext = os.path.splitext(filename)[1].lower()
        
        try:
            if ext in ['.xlsx', '.xls']:
                df = pd.read_excel(filename)
                return df.values
            elif ext == '.csv':
                df = pd.read_csv(filename)
                return df.values
            elif ext == '.txt':
                with open(filename, 'r') as file:
                    lines = file.readlines()
                return np.array([list(line.strip()) for line in lines])
            elif ext == '.json':
                with open(filename, 'r') as file:
                    data = json.load(file)
                return np.array(data)
            elif ext == '.pdf':
                text_content = []
                with open(filename, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    for page in pdf_reader.pages:
                        text_content.append(list(page.extract_text()))
                return np.array(text_content)
            elif ext == '.docx':
                doc = Document(filename)
                content = []
                for para in doc.paragraphs:
                    if para.text.strip():
                        content.append(list(para.text))
                return np.array(content)
            else:
                raise ValueError(f"Unsupported file format: {ext}")
        except Exception as e:
            raise Exception(f"Error reading file: {str(e)}")

    def load_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[
                ('All supported', '*.xlsx;*.xls;*.csv;*.txt;*.json;*.pdf;*.docx'),
                ('Excel files', '*.xlsx;*.xls'),
                ('CSV files', '*.csv'),
                ('Text files', '*.txt'),
                ('JSON files', '*.json'),
                ('PDF files', '*.pdf'),
                ('Word files', '*.docx')
            ]
        )
        
        if filename:
            try:
                data = self.read_file_content(filename)
                
                if self.direction.get() == "left-right":
                    data = data.T
                
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, str(data))
                
            except Exception as e:
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, f"Error: {str(e)}")

    def copy_to_clipboard(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.result_display.get(1.0, tk.END))

if __name__ == "__main__":
    root = ThemedTk(theme="arc")  # Modern theme
    app = FileArrayConverter(root)
    root.mainloop()