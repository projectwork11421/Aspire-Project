import tkinter as tk
from tkinter import filedialog, ttk
import numpy as np
import pandas as pd
import json
from docx import Document
import PyPDF2
import os
from ttkthemes import ThemedTk

class FileArrayConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("File Array Converter")
        self.root.geometry("800x600")
        
        self.setup_styles()
        self.direction = tk.StringVar(value="top-bottom")
        self.array_mode = tk.StringVar(value="indexed")
        self.current_data = None
        
        self.create_gui()

    def setup_styles(self):
        style = ttk.Style()
        style.configure("Custom.TFrame", background="#f5f5f5")
        style.configure("Custom.TButton", padding=10, font=('Helvetica', 10, 'bold'))
        style.configure("Custom.TLabel", font=('Helvetica', 10), padding=5)
        style.configure("Custom.TRadiobutton", font=('Helvetica', 10), padding=5)
        style.configure("Title.TLabel", font=('Helvetica', 14, 'bold'), padding=10)

    def create_gui(self):
        main_frame = ttk.Frame(self.root, style="Custom.TFrame", padding="20")
        main_frame.grid(sticky="nsew")
        self.setup_grid_weights(main_frame)

        self.create_file_section(main_frame)
        self.create_options_section(main_frame)
        self.create_result_section(main_frame)

    def setup_grid_weights(self, frame):
        frame.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

    def create_file_section(self, parent):
        controls = ttk.Frame(parent)
        controls.grid(row=0, sticky="ew")
        controls.grid_columnconfigure(1, weight=1)

        ttk.Button(controls, text="Select File", command=self.load_file, style="Custom.TButton").grid(row=0, column=0, padx=5)
        ttk.Label(controls, text="Supported: Excel, CSV, Text, JSON, PDF, DOCX", style="Custom.TLabel").grid(row=0, column=1, padx=5)

    def create_options_section(self, parent):
        options = ttk.Frame(parent)
        options.grid(row=1, pady=10, sticky="ew")
        options.grid_columnconfigure((0, 1), weight=1)

        # Array Mode Options
        array_frame = ttk.LabelFrame(options, text="Array Mode", padding="10")
        array_frame.grid(row=0, column=0, sticky="ew", padx=5)
        array_frame.grid_columnconfigure((0, 1), weight=1)
        
        ttk.Radiobutton(array_frame, text="Word Indexed", variable=self.array_mode, 
                       value="indexed", command=self.update_display).grid(row=0, column=0)
        ttk.Radiobutton(array_frame, text="Normal Array", variable=self.array_mode, 
                       value="normal", command=self.update_display).grid(row=0, column=1)

        # Direction Options
        direction_frame = ttk.LabelFrame(options, text="Reading Direction", padding="10")
        direction_frame.grid(row=0, column=1, sticky="ew", padx=5)
        direction_frame.grid_columnconfigure((0, 1), weight=1)
        
        ttk.Radiobutton(direction_frame, text="Top to Bottom", variable=self.direction, 
                       value="top-bottom", command=self.update_display).grid(row=0, column=0)
        ttk.Radiobutton(direction_frame, text="Left to Right", variable=self.direction, 
                       value="left-right", command=self.update_display).grid(row=0, column=1)

    def create_result_section(self, parent):
        result_frame = ttk.LabelFrame(parent, text="Array Output", padding="10")
        result_frame.grid(row=2, sticky="nsew", pady=10)
        result_frame.grid_columnconfigure(0, weight=1)
        result_frame.grid_rowconfigure(0, weight=1)
        parent.grid_rowconfigure(2, weight=1)

        self.result_display = tk.Text(result_frame, wrap=tk.WORD, font=('Consolas', 11),
                                    bg='#ffffff', fg='#333333', padx=10, pady=10)
        self.result_display.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = ttk.Scrollbar(result_frame, orient="vertical", command=self.result_display.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.result_display.configure(yscrollcommand=scrollbar.set)
        
        ttk.Button(result_frame, text="Copy to Clipboard", 
                  command=self.copy_to_clipboard, style="Custom.TButton").grid(row=1, column=0, columnspan=2, pady=(10, 0))

    def process_data(self, data):
        if self.array_mode.get() == "indexed":
            if isinstance(data, np.ndarray):
                result = []
                for i, row in enumerate(data):
                    words = str(row).split()
                    indexed_words = {f"[{i}][{j}]": word for j, word in enumerate(words)}
                    result.append(indexed_words)
                return result
            return data
        return data

    def format_output(self, data):
        if self.array_mode.get() == "indexed":
            return '\n'.join([str(row) for row in data])
        return str(data)

    def read_file_content(self, filename):
        ext = os.path.splitext(filename)[1].lower()
        
        try:
            if ext in ['.xlsx', '.xls']:
                return pd.read_excel(filename).values
            elif ext == '.csv':
                return pd.read_csv(filename).values
            elif ext == '.txt':
                with open(filename, 'r') as file:
                    return np.array([line.strip() for line in file.readlines()])
            elif ext == '.json':
                with open(filename, 'r') as file:
                    return np.array(json.load(file))
            elif ext == '.pdf':
                with open(filename, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    return np.array([page.extract_text() for page in pdf_reader.pages])
            elif ext == '.docx':
                doc = Document(filename)
                return np.array([para.text for para in doc.paragraphs if para.text.strip()])
            else:
                raise ValueError(f"Unsupported file format: {ext}")
        except Exception as e:
            raise Exception(f"Error reading file: {str(e)}")

    def update_display(self):
        if self.current_data is not None:
            data = self.current_data.T if self.direction.get() == "left-right" else self.current_data
            processed_data = self.process_data(data)
            self.result_display.delete(1.0, tk.END)
            self.result_display.insert(tk.END, self.format_output(processed_data))

    def load_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[
                ('All supported', '*.xlsx;*.xls;*.csv;*.txt;*.json;*.pdf;*.docx'),
                ('Excel files', '*.xlsx;*.xls'),
                ('CSV files', '*.csv'),
                ('Text files', '*.txt'),
                ('JSON files', '*.json'),
                ('PDF files', '*.pdf'),
                ('Word files', '*.docx')
            ]
        )
        
        if filename:
            try:
                self.current_data = self.read_file_content(filename)
                self.update_display()
            except Exception as e:
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, f"Error: {str(e)}")

    def copy_to_clipboard(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.result_display.get(1.0, tk.END))

if __name__ == "__main__":
    root = ThemedTk(theme="arc")
    app = FileArrayConverter(root)
    root.mainloop()