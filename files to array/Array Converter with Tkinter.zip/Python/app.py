import tkinter as tk
from tkinter import filedialog, ttk
import numpy as np
import pandas as pd
import json
from docx import Document
import PyPDF2
import os
from ttkthemes import ThemedTk

class FileArrayConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("File Array Converter")
        self.root.geometry("800x600")
        
        self.setup_styles()
        self.direction = tk.StringVar(value="top-bottom")
        self.array_mode = tk.StringVar(value="indexed")
        self.current_data = None
        
        self.create_gui()

    def setup_styles(self):
        """Setup ttk styles for the GUI"""
        style = ttk.Style()
        style.configure("Custom.TFrame", background="#f5f5f5")
        style.configure("Custom.TButton", padding=10, font=('Helvetica', 10, 'bold'))
        style.configure("Custom.TLabel", font=('Helvetica', 10), padding=5)
        style.configure("Custom.TRadiobutton", font=('Helvetica', 10), padding=5)
        style.configure("Title.TLabel", font=('Helvetica', 14, 'bold'), padding=10)

    def create_gui(self):
        """Create the main GUI layout"""
        main_frame = ttk.Frame(self.root, style="Custom.TFrame", padding="20")
        main_frame.grid(sticky="nsew")
        self.setup_grid_weights(main_frame)

        self.create_file_section(main_frame)
        self.create_options_section(main_frame)
        self.create_result_section(main_frame)

    def setup_grid_weights(self, frame):
        """Configure grid weights for responsive layout"""
        frame.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

    def create_file_section(self, parent):
        """Create the file selection section"""
        controls = ttk.Frame(parent)
        controls.grid(row=0, sticky="ew")
        controls.grid_columnconfigure(1, weight=1)

        ttk.Button(controls, text="Select File", command=self.load_file, style="Custom.TButton").grid(row=0, column=0, padx=5)
        ttk.Label(controls, text="Supported: Excel, CSV, Text, JSON, PDF, DOCX", style="Custom.TLabel").grid(row=0, column=1, padx=5)

    def create_options_section(self, parent):
        """Create the options section with radio buttons"""
        options = ttk.Frame(parent)
        options.grid(row=1, pady=10, sticky="ew")
        options.grid_columnconfigure((0, 1), weight=1)

        # Array Mode Options
        array_frame = ttk.LabelFrame(options, text="Array Mode", padding="10")
        array_frame.grid(row=0, column=0, sticky="ew", padx=5)
        array_frame.grid_columnconfigure((0, 1), weight=1)
        
        ttk.Radiobutton(array_frame, text="Word Indexed", variable=self.array_mode, 
                       value="indexed", command=self.update_display).grid(row=0, column=0)
        ttk.Radiobutton(array_frame, text="Normal Array", variable=self.array_mode, 
                       value="normal", command=self.update_display).grid(row=0, column=1)

        # Direction Options
        direction_frame = ttk.LabelFrame(options, text="Reading Direction", padding="10")
        direction_frame.grid(row=0, column=1, sticky="ew", padx=5)
        direction_frame.grid_columnconfigure((0, 1), weight=1)
        
        ttk.Radiobutton(direction_frame, text="Top to Bottom", variable=self.direction, 
                       value="top-bottom", command=self.update_display).grid(row=0, column=0)
        ttk.Radiobutton(direction_frame, text="Left to Right", variable=self.direction, 
                       value="left-right", command=self.update_display).grid(row=0, column=1)

    def create_result_section(self, parent):
        """Create the result section with text display"""
        result_frame = ttk.LabelFrame(parent, text="Array Output", padding="10")
        result_frame.grid(row=2, sticky="nsew", pady=10)
        result_frame.grid_columnconfigure(0, weight=1)
        result_frame.grid_rowconfigure(0, weight=1)
        parent.grid_rowconfigure(2, weight=1)

        self.result_display = tk.Text(result_frame, wrap=tk.WORD, font=('Consolas', 11),
                                    bg='#ffffff', fg='#333333', padx=10, pady=10)
        self.result_display.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = ttk.Scrollbar(result_frame, orient="vertical", command=self.result_display.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.result_display.configure(yscrollcommand=scrollbar.set)
        
        ttk.Button(result_frame, text="Copy to Clipboard", 
                  command=self.copy_to_clipboard, style="Custom.TButton").grid(row=1, column=0, columnspan=2, pady=(10, 0))

    def read_docx_file(self, filename):
        """Read DOCX file with enhanced error handling"""
        try:
            doc = Document(filename)
            # Extract text from paragraphs, tables, and other elements
            content = []
            
            # Process paragraphs
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    content.append(paragraph.text.split())
            
            # Process tables
            for table in doc.tables:
                for row in table.rows:
                    row_content = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_content.extend(cell.text.split())
                    if row_content:
                        content.append(row_content)
            
            return content if content else [['']]
            
        except Exception as e:
            error_msg = f"Error reading DOCX file: {str(e)}\n"
            error_msg += "Please ensure:\n"
            error_msg += "1. The file exists and is not corrupted\n"
            error_msg += "2. You have read permissions for the file\n"
            error_msg += "3. The python-docx package is installed (pip install python-docx)"
            raise Exception(error_msg)

    def normalize_data(self, data):
        """Convert different data types into a consistent list format"""
        if isinstance(data, (str, int, float)):
            return [[str(data)]]
        elif isinstance(data, (list, tuple)):
            if not data:
                return [[]]
            if isinstance(data[0], (list, tuple)):
                return [[str(item) for item in row] for row in data]
            return [[str(item)] for item in data]
        elif isinstance(data, dict):
            return [[str(k), str(v)] for k, v in data.items()]
        elif isinstance(data, pd.DataFrame):
            return data.astype(str).values.tolist()
        elif isinstance(data, np.ndarray):
            if data.dtype == object:
                return [[str(item) for item in row] if isinstance(row, (list, np.ndarray)) else [str(row)] 
                       for row in data]
            if data.ndim == 1:
                return [[str(item)] for item in data]
            return data.astype(str).tolist()
        else:
            return [[str(data)]]

    def process_data(self, data):
        """Process the normalized data according to the selected mode"""
        try:
            normalized_data = self.normalize_data(data)
            
            if self.array_mode.get() == "indexed":
                result = []
                for i, row in enumerate(normalized_data):
                    if isinstance(row, (list, np.ndarray)):
                        indexed_words = {f"[{i}][{j}]": str(word).strip() 
                                      for j, word in enumerate(row) if str(word).strip()}
                    else:
                        indexed_words = {f"[{i}][0]": str(row).strip()}
                    if indexed_words:
                        result.append(indexed_words)
                return result
            else:
                return normalized_data
        except Exception as e:
            raise Exception(f"Error processing data: {str(e)}")

    def read_file_content(self, filename):
        """Read and parse different file types"""
        ext = os.path.splitext(filename)[1].lower()
        
        try:
            if ext in ['.xlsx', '.xls']:
                df = pd.read_excel(filename, dtype=str)
                return df.values.tolist()
            elif ext == '.csv':
                df = pd.read_csv(filename, dtype=str)
                return df.values.tolist()
            elif ext == '.txt':
                with open(filename, 'r', encoding='utf-8') as file:
                    return [line.strip().split() for line in file.readlines() if line.strip()]
            elif ext == '.json':
                with open(filename, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    return self.normalize_data(data)
            elif ext == '.pdf':
                with open(filename, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    pages = []
                    for page in pdf_reader.pages:
                        text = page.extract_text()
                        if text.strip():
                            pages.extend([line.split() for line in text.split('\n') if line.strip()])
                    return pages
            elif ext == '.docx':
                return self.read_docx_file(filename)
            else:
                raise ValueError(f"Unsupported file format: {ext}")
        except Exception as e:
            raise Exception(f"Error reading file: {str(e)}")

    def update_display(self):
        """Update the display with the processed data"""
        if self.current_data is not None:
            try:
                data_list = self.normalize_data(self.current_data)
                
                if self.direction.get() == "left-right":
                    max_len = max(len(row) for row in data_list)
                    padded_data = [row + [''] * (max_len - len(row)) for row in data_list]
                    transposed_data = list(map(list, zip(*padded_data)))
                    data_to_process = transposed_data
                else:
                    data_to_process = data_list
                
                processed_data = self.process_data(data_to_process)
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, self.format_output(processed_data))
            except Exception as e:
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, f"Error updating display: {str(e)}")

    def format_output(self, data):
        """Format the processed data for display"""
        try:
            if self.array_mode.get() == "indexed":
                return '\n'.join([str(row) for row in data if row])
            else:
                return '\n'.join([str(row) for row in data if any(str(x).strip() for x in row)])
        except Exception as e:
            raise Exception(f"Error formatting output: {str(e)}")

    def load_file(self):
        """Open file dialog and load selected file"""
        filename = filedialog.askopenfilename(
            filetypes=[
                ('All supported', '*.xlsx;*.xls;*.csv;*.txt;*.json;*.pdf;*.docx'),
                ('Excel files', '*.xlsx;*.xls'),
                ('CSV files', '*.csv'),
                ('Text files', '*.txt'),
                ('JSON files', '*.json'),
                ('PDF files', '*.pdf'),
                ('Word files', '*.docx')
            ]
        )
        
        if filename:
            try:
                self.current_data = self.read_file_content(filename)
                self.update_display()
            except Exception as e:
                self.result_display.delete(1.0, tk.END)
                self.result_display.insert(tk.END, f"Error: {str(e)}")

    def copy_to_clipboard(self):
        """Copy the displayed content to clipboard"""
        self.root.clipboard_clear()
        self.root.clipboard_append(self.result_display.get(1.0, tk.END))

if __name__ == "__main__":
    root = ThemedTk(theme="arc")
    app = FileArrayConverter(root)
    root.mainloop()